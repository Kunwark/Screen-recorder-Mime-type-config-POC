let startButton = document.getElementById('start');
let pauseButton = document.getElementById('pause');
let stopButton = document.getElementById('stop');
let saveButton = document.getElementById('save');
let saveRecordingForm = document.getElementById("saveForm");
let videoElement = document.getElementById('videoDisplay');
let chunks = [];


async function fetchRecordingsList() {
    try {
        const response = await fetch('/get-recordings');
        const data = await response.json();

        if (data.success) {
            const recordingsList = document.getElementById('recordingsList');
            recordingsList.innerHTML = ''; // Clear existing list

            data.recordings.forEach(filename => {
                const listItem = document.createElement('li');
                listItem.textContent = filename;

                // Add an event listener to play the video when the list item is clicked
                listItem.addEventListener('click', () => playRecording(filename));

                recordingsList.appendChild(listItem);
            });
        } else {
            console.error('Error fetching recordings list:', data.error);
        }
    } catch (error) {
        console.error('Error fetching recordings list:', error);
    }
}
async function playRecording(filename) {
    const videoElement = document.getElementById('videoDisplay');
    console.log(filename);

    // Clear any existing chunks
    chunks = [];

    // Set the video source to play the selected recording
    videoElement.src = `/recordings/${filename}`;

    console.log(videoElement.src);

    // Enable the save button
    saveButton.disabled = false;
}

document.addEventListener('DOMContentLoaded', () => {
    // Fetch and display the recordings list when the DOM has finished loading
    fetchRecordingsList().catch(error => {
        console.error('Error fetching recordings list:', error);
    });
});

if (navigator.mediaDevices) {
    const mime = MediaRecorder.isTypeSupported("video/webm; codecs=vp9") ? "video/webm; codecs=vp9" : "video/webm";
    // grab all the buttons and add event listner. Browser listners are to be handled seperately. 
    console.log("mime type is ", mime);
    startButton.addEventListener('click', startRecording);


    async  function startRecording(){

        startButton.disabled = true;

        pauseButton.addEventListener('click',pauseRecording);
        pauseButton.removeAttribute("disabled");
        stopButton.addEventListener('click',stopRecording);
        stopButton.removeAttribute("disabled");

        let mediaStream = await startCapture({
            video: true
        })

        let mediaRecorder = new MediaRecorder(mediaStream,{
            mimeType: mime
        });

        mediaRecorder.addEventListener('dataavailable', function(e) {
            chunks.push(e.data)
        })

        mediaRecorder.addEventListener('stop', function(){
            let blob = new Blob(chunks, {
                type: chunks[0].type
            })

            // const buffer = Buffer.from(blob.arrayBuffer());
            // const readStream = Readable.from(buffer);

            console.log("chunks type is ", chunks[0].type);
            console.log(blob);

            startButton.disabled = false;

            let video = document.querySelector("video")
            video.src = URL.createObjectURL(blob)

            let a = document.createElement('a')
            a.href = URL.createObjectURL(blob)
            a.download = 'video.webm'
            a.click()
            saveRecording();
        })


        mediaStream.getVideoTracks()[0].addEventListener('ended', () => {
            stopRecording()
            console.log('screen sharing has ended.')
        });
        mediaStream.getVideoTracks()[0].addEventListener('mute', () => console.log('screen sharing has ended'));
        mediaStream.getVideoTracks()[0].addEventListener('unmute', () => console.log('screen sharing has ended'));


        function stopRecording(){
            let tracks = mediaStream.getTracks();
            tracks.forEach(track => track.stop());
            mediaStream = null;
            mediaRecorder.stop();
            document.getElementById('start').disabled = false;



            saveButton.addEventListener('click',saveRecording);
            pauseButton.disabled = true;
            stopButton.disabled = true;
            saveButton.disabled = false;

            console.log('Screen recording stopped.');
        }


        mediaRecorder.start();
        console.log('Screen recording initiated.');
    }  //  function startRecording(){
    
    function pauseRecording(){
        console.log('Screen recording paused.');
    } 
    function resumeRecording(){
        console.log('Screen recording resumed.');
    }



    function saveRecording(e = null) {
        if(e != null){
            e.preventDefault();
        }
        console.log('Saving recording.');

        // Disable the save button
        saveButton.disabled = true;

        // Create a FormData object to send the recording file to the server
        const formData = new FormData();
        let blob = new Blob(chunks, {
            type: chunks[0].type
        })
        formData.append('recording', blob);


        // Use fetch to send a POST request to the server
        fetch('/save-recording', {
            method: 'POST',
            body: formData,
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error saving recording');
                }
                console.log('Recording saved!');
            })
            .catch(error => {
                console.error(error);
                console.log('Error saving recording');
            });
    }


    async function startCapture(displayMediaOptions) {
        let captureStream = null;

        try {
          captureStream = await navigator.mediaDevices.getDisplayMedia(displayMediaOptions);
        } catch (err) {
          console.error(`Error: ${err}`);
        }
        return captureStream;
      }

    console.log("getUserMedia supported.");
}else{
    console.log("getUserMedia is not supported.");
}
  